import java.io.*;

class Node
{

	int data;
	Node left;
	Node right;
	public Node(int key)
	{
		data=key;
		left=right=null;
	}
}

class Tree
{
		Node root=null;
		

		void inorder(Node root)
		{
			if(root==null)
			{
				return;
			}
				inorder(root.left);
				System.out.print(root.data+" ");
				inorder(root.right);
			
		}
}


class Main_Inorder
{

	public static void main(String args[])
	{
		
		Scanner in=new Scanner(System.in);
		
		Tree obj=new Tree();
					
		obj.root= new Node(12);
		obj.root.left=new Node(23);
		obj.root.right=new Node(32);
		obj.root.left.left=new Node(24);
		System.out.println("Inorder tree:");
		obj.inorder(obj.root);
	}
}
		