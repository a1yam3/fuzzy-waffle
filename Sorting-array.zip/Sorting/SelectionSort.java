import java.io.*;
import java.util.Scanner;

class SelectionSort
{
	int selsort(int a[],int n){
		int min,temp;
		boolean flag= false; 
		for(int i=0;i<n,i++{
			min=i; flag
			for(int j=i+1;j<n;j++){
				if(a[j]<a[min]){
					min=j; flag=true;
				}
				
				if (flag==true)
				{
					temp=a[i];
					a[i]=a[min];
					a[min]=a[i];
				}
			}
		}	return a;
	}

	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		System.out.println("Enter size of array");
    		int m=in.nextInt();
    
    		int arr[]=new int[m];
    		System.out.println("Enter unsorted elements of array");
    		for(int i=0;i<m;i++)
			arr[i]=in.nextInt();
    
		int res= bblsort(arr,m);
		System.out.println("Sorted  elements of array");
    		for(int i=0;i<m;i++)
			System.out.print(arr[i]+" ");
	}
}