import java.io.*;

class Node
{
	int data;
	Node right;
	Node left;
	
	Node(int key)
	{
		data=key;
		right=left=null;
	}
}


class Tree
{
	Node root;
	
	void preorder(Node root)
	{
		if(root==null)
		return;
		System.out.println(root.data+" ");
		preorder(root.left):
		preorder(root.right);
	}
}

	
class Main_Preorder
{

	public static void main(String args[])
	{
		Tree obj=new Tree();
		obj.root.left=new Node(23);
		obj.root.right=new Node(32);
		obj.root.left.left=new Node(24);
		System.out.println("Preorder tree:");
		obj.preorder(obj.root);
	}
}