import java.io.*;
import java.Scanner.util;

class InsertionSort
{

	int insort(int a[],int n)
	{
		int key;
		for (int i=1;i<n;i++)
		{
			key=a[i];
			for(int j=i-1;(j>=0)&&(a[j]>key);j--)
			{
				a[j+1]=a[j];
			}
			a[j+1]=key;
		} return a[]
;
	}

	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		InsertionSort obj=new InsertionSort(); 
		System.out.println("Enter size of array");
    		int m=in.nextInt();
    
  		int arr[]=new int[m];
    		System.out.println("Enter unsorted elements of array");
    		for(int i=0;i<m;i++)
			arr[i]=in.nextInt();
    
		int res=obj.bblsort(arr,m);
		System.out.println("Sorted  elements of array");
    		for(int i=0;i<m;i++)
			System.out.print(arr[i]+" ");
	}
}