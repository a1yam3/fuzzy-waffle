import java.io.*;
import java.util.Scanner;

class BubbleSort
{
	int bblsort(int a[], int n)
	{
		int temp;
		for(int i=0;i<n;i++)
		{
			for (int j=0;j<=n-i-1;j++)
			{
				if(a[j]>a[j+1])
				{
					temp=a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
				}
			}
		}
		return a[n];
	}


	public static void main(String args[])
	{
		Scanner in =new Scanner(System.in);
		System.out.println("Enter size of array");
    		int m=in.nextInt();
    
    		int arr[]=new int[m];
    		System.out.println("Enter unsorted elements of array");
    		for(int i=0;i<m;i++)
			arr[i]=in.nextInt();
    
		int res= bblsort(arr,m);
		System.out.println("Sorted  elements of array");
    		for(int i=0;i<m;i++)
			System.out.print(arr[i]+" ");
	}
}