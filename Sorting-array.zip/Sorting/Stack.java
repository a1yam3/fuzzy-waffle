import java.io.*;
import java.util.Scanner;
import stackpack;
public class Stack{

	int top=-1;
	int stkarr[];
	int n;
	Stack(int n){
	this.n=n;
	stkarr[]=new int[n];
	}

	public void push(int data)
	{
		if(isFull()==true)
		System.out.println("Stack is full");
		else{
		top++;
		stkarr[top]= data;
		}
	}

	public int pop()
	{
		if(isEmpty()==true)
		System.out.println("Stack is empty");
		else{
		int r=stkarr[top];
		stkarr[top]=0;
		top--;
		}
		return r;
	}

	public int peek()
	{
		if(isEmpty()==true)
		System.out.println("Stack is empty");
		else{
		return stkarr[top];
		}
	}

	public boolean isFull(){
	if(top==n-1)
	return true;
	else
	return false;
	}

	public boolean isEmpty(){
	if(top==-1)
	return true;
	else 
	return false;
	}

	public display()
	{
		for(int i=top;i>-1;i++)
		{
			System.out.println(stkarr[i]+" ");
		}
		System.out.println();
	}

}
	

	

	
		