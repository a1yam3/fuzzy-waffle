import java.io.*;
import java.util.Scanner;
import linkedpack;

public class LinkedList{
	
	Node head;
	public void insertAtStart(int d)
	{
		Node temp=new Node();
		//temp is used to insert the node		
		temp.data=d;
		temp.next=null;
		//check whether list is empty
		if (head==null)
		{
			head=temp;	
		}
		else
5//makes the next empty nde the header and inserts a new node

			temp.next=head;
			head= temp;
		}
	}

	public void display()
	{

		Node t=head;
		if(t==null)
		{
			System.out.println("List is empty");
		}
		else
		{
			while(t.next!=null)
		{
			System.out.println(t.data);
			t=t.next;
		}
		System.out.println(t.data);	
			
	}


	public void insertAtEnd(int d, int pos)
	{
		Node temp=new Node();
		temp.data= d;
		temp.next= null;
		t=head;
		while(t.next!=null)
		{
			t=t.next
		}
			t.next=temp;

	}
			
	public void insertAtPos(int d, int pos)
	{
		Node temp=new Node();
		temp.data= d;
		temp.next= null;
		Node t= head;
		if(pos==1)
		{
			temp.next= head;
			head= temp;
			return;
		}
		if(t==null)
		{
			System.out.println("List is empty");
		}

		else
		{
			for(int i=1; i<pos-1&& t!=null;i++)
			{
				t= t.next;
			}

			temp.next=t.next;
			t.next= temp;
		}
	}

	public void deleteAtStart()
	{
		if(head!=null)
		{
			head=head.next;
		}
	}

	public void deleteAtEnd()
	{
		if(head==null)
		{
			System.out.println(x:"The list is empty");
			return;
		}
		if(head.next==null)
		{
			head=null;
			return head;
		}

	}
}
		
		
