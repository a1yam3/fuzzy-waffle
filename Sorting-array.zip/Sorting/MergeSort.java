import java.io.*;
import java.util.Scanner;

class MergeSort
{

	int Merge_Sort(int arr[],int l,int r)
	{
		if (l < r)
		{
		int mid = (l + r)/2;
		Merge_Sort(arr, l, mid);
		Merge_Sort(arr, mid + 1, r);
		int b[]=new int[r+1];
		b=merge (arr, l, mid, r);
		}
		return b;
	}

	void merge(int a[], int beg, int mid, int end)
	{
		int k;
		int n1=mid-beg+1;
		int n2= end-mid;
		int LA[]= new int [n1]; 
		int RA[]=new int[n2];
		/*copy data to temp array*/

		for(int i=0;i<n1;i++)
			LA[i]=a[beg+i];
		for(int j=0;j<n2;j++)
			RA[j]=a[mid+1+j];

		i=0;//initial index of first sub-array
		j=0;//intial index of the second sub-array
		k=beg;//initial index of merged array
		while(i<n1&& j<n2)
		{
			if(LA[i]<=RA[j])
			{
				a[k]=LA[i];
				i++;
			}
			else
			{
				a[k]=RA[j];
				j++;
			}
				k++;
		}
		while(i<n1)
		{
			a[k]=LA[i];
			i++;
			k++;
		}
		
		while(j<n2)
		{
			a[k]=RA[j];
			j++;
			k++;
		}

		 
	}



	public static void main(String args[]){
		/*Scanner in=new Scanner(System.in);
		
		System.out.println("Enter size of array");
    		int n=in.nextInt();
    
    		int arr[]=new int[n];
    		System.out.println("Enter elements of array");
    		for(int i=0;i<n;i++)
			arr[i]=in.nextInt();*/
		int arr[]=new int[5];
    		arr=[5,3,6,1,8];
		int l=0;
		int r=n-1;
		int un_arr[]=new int [5];
		un_arr =Merge_sort(arr,l,r);
		for(int i=0;i<5;i++)
			System.out.print(" "+un_arr[i]);
  		

	}
}