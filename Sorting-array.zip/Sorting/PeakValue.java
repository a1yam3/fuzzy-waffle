5import java.io.*;
import java.util.Scanner;

class PeakValue
{

	int peak(int l,int r,int mid,int ar[])
	{
		boolean flag=false;
		while (flag==false){
			if((ar[mid]>ar[mid+1])&&(ar[mid]>ar[mid-1])){
				return a[mid];
				flag=true;
			{
			
			if (ar[mid]<ar[mid+1]){
				l=mid+1;
				mid=(l+r)/2;
			}
			
			if (ar[mid]<ar[mid-1]){
				r=mid-1;
				mid=(l+r)/2;
			}
		 		
				return -1;
		}
	}



	public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		
		System.out.println("Enter size of array");
    		int n=in.nextInt();
    
    		int arr[]=new int[n];
    		System.out.println("Enter sorted elements of array");
    		for(int i=0;i<n;i++)
			arr[i]=in.nextInt();
		
		int l=0;
		int r=n-1;
		int mid= (l+r)/2;

    		int res=peak(l,r,mid,arr);
		if (res!=-1)
			System.out.println("Element found"+res);
	}
}