package linkedpack;
public class LinkedListDemo 
{
	public static void main(String args[])
	{

		LinkedList l= new LinkedList();
		l.display();
		l.insertAtStart(d:45);
		l.insertAtStart(d:18);
		l.insertAtStart(d:35)
		l.display();
		l.insertAtPos(d:30,pos:2);
		l.display();

	}
