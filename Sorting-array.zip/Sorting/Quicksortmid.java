import java.io.*;
import java.util.Scanner;

class Quicksortmid{

	void quickSort(int[] array, int low, int high) {
        if (low < high) {
            int pivot = array[(low + high) / 2];
            int i = low;
            int j = high;
            while (i <= j) {
                while (array[i] < pivot) {
                    i++;
                }
                while (array[j] > pivot) {
                    j--;
                }
                if (i <= j) {
                    int temp = array[i];
                    array[i] = array[j];
                    array[j] = temp;
                    i++;
                    j--;
                }
            }
            quickSort(array, low, j);
            quickSort(array, i, high);
        }
	}

	public static void main (String[] args) {
		Scanner in=new Scanner(System.in);
		System.out.println("Enter size of array");
    		int n=in.nextInt(); 
    
    		int arr[]=new int[n];
    		System.out.println("Enter elements of array");
    		for(int i=0;i<n;i++)
			arr[i]=in.nextInt();
   
		System.out.println("Unsorted array:");
		for(int i=0;i<n;i++)
		{
		    System.out.print(arr[i] + " ");
		}
		
		Quicksortmid obj = new Quicksortmid();
        	obj.quickSort(arr, 0, n-1);
		
		
		System.out.println("\nSorted array:");
		for(int i=0;i<n;i++)
		{
		    System.out.print(arr[i] + " ");
		}
	}
}	