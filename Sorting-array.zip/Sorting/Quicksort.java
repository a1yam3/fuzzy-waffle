import java.util.Scanner;
import java.util.*;

public class Quicksort {
    
    static int partition(int[] num, int i, int j)
    {

        int pivot = num[(i+j)/2];
        
        
        while(i < j)
        {
                  while(num[i] < pivot)
            {
                i++;
            }
            
            
            while(pivot < num[j])
            {
                j--;
            }
            
            
            if(i <= j)
            {
                int temp = num[i];
                num[i] = num[j];
                num[j] = temp;
                
                
                i++;
                j--;
            }
        }      
        return i;
    }
    
    
    static void quicksort(int[] num, int i, int j)
    {
        int pivot_index = partition(num, i, j);
        
        
        if(i < pivot_index-1)
        {
            quicksort(num, i, pivot_index-1);
        }
        
        
        if(pivot_index < j)
        {
            quicksort(num, pivot_index+1, j);
        }

    }
	public static void main (String[] args) {
		Scanner in=new Scanner(System.in);
		System.out.println("Enter size of array");
    		int n=in.nextInt(); 
    
    		int arr[]=new int[n];
    		System.out.println("Enter elements of array");
    		for(int i=0;i<n;i++)
			arr[i]=in.nextInt();
   
		System.out.println("Unsorted array:");
		for(int i=0;i<n;i++)
		{
		    System.out.print(arr[i] + " ");
		}
		
		
		quicksort(arr, 0, n-1);
		
		
		System.out.println("Sorted array:");
		for(int i=0;i<n;i++)
		{
		    System.out.print(arr[i] + " ");
		}	
	}
}
