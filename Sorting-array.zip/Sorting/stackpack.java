package stackpack;

class Mainstack
{
	
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		System.out.println("Enter the size of the array);
		int t=in.nextInt();
		Stack obj=new Stack(t);
		System.out.println("enter 1.Push 2.Pop 3.Peek 4.Diplay 5.Count Elements 6.Exit)
		int op= in.nextInt():
		switch(op){
			case 1:
			System.out.println("Enter the element to be inserted");
			int el=in.nextInt();
			obj.push(el);
			obj.display();
			case 2:
			el