class InvalidAccountNumberException extends Exception {
   public InvalidAccountNumberException(String var1) {
      super(var1);
   }
}
