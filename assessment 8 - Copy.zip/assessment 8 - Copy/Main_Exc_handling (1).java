import java.util.Scanner;

class Main_Exc_handling {
   public static void main(String[] var0) {
      Exc_handling var1 = new Exc_handling();
      Scanner var2 = new Scanner(System.in);
      System.out.println("Enter two numbers to divide");
      int var3 = var2.nextInt();
      int var4 = var2.nextInt();
      var1.divide(var3, var4);
      System.out.println("Enter index number");
      int var5 = var2.nextInt();
      var1.Array_index(var5);
   }
}
