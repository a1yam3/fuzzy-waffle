class BankAccount {
   private String accountNumber;
   private double balance;

   public BankAccount(String var1, double var2) {
      this.accountNumber = var1;
      this.balance = var2;
   }

   public void deposit(double var1) {
      this.balance += var1;
      System.out.println("Deposited: $" + var1);
      System.out.println("Current Balance: $" + this.balance);
   }

   public void withdraw(double var1) throws InsufficientFundsException {
      if (var1 > this.balance) {
         throw new InsufficientFundsException("Insufficient funds. Cannot withdraw $" + var1);
      } else {
         this.balance -= var1;
         System.out.println("Withdrawn: $" + var1);
         System.out.println("Current Balance: $" + this.balance);
      }
   }

   public void performTransaction(String var1, double var2) throws InvalidAccountNumberException, InsufficientFundsException {
      boolean var4 = true;
      if (!var4) {
         throw new InsufficientFundsException("Unauthorized transaction. Cannot transfer $" + var2);
      } else if (!var1.equals("validTargetAccountNumber")) {
         throw new InvalidAccountNumberException("Invalid target account number: " + var1);
      } else {
         this.withdraw(var2);
         System.out.println("Transaction in progress...");
         System.out.println("Funds transferred to account: " + var1);
      }
   }
}
