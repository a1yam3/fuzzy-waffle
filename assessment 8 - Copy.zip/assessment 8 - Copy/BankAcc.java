class BankAcc {
   private int acc_number;
   private double balance;

   public BankAcc(int var1, double var2) {
      this.acc_number = var1;
      this.balance = var2;
   }

   public void deposit(double var1) {
      this.balance += var1;
      System.out.println("Amount deposited: " + var1);
   }

   public void withdraw(double var1) throws InsufficientFundsException {
      if (var1 > this.balance) {
         throw new InsufficientFundsException("Insufficient funds");
      } else {
         this.balance -= var1;
         System.out.println("Withdrawn: $" + var1);
         System.out.println("Current Balance: $" + this.balance);
      }
   }
}
