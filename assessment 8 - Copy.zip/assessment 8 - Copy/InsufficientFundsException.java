class InsufficientFundsException extends Exception {
   public InsufficientFundsException(String var1) {
      super(var1);
   }
}
