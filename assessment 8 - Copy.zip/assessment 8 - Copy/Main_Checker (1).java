class Main_Checker {
   public static void main(String[] var0) {
      CheckEvenNumber var1 = new CheckEvenNumber();

      try {
         var1.checkEvenNumber(4);
         var1.checkEvenNumber(7);
      } catch (OddNumberException var3) {
         System.out.println("Exception: " + var3.getMessage());
      }

   }
}
