class BankingSystem {
   public static void main(String[] var0) {
      try {
         BankAccount var1 = new BankAccount("123456", 1000.0D);
         var1.deposit(500.0D);
         var1.withdraw(200.0D);
         var1.performTransaction("456789", 300.0D);
         var1.performTransaction("invalidAccountNumber", 100.0D);
      } catch (InvalidAccountNumberException | InsufficientFundsException var2) {
         System.out.println("Exception: " + var2.getMessage());
      }

   }
}
